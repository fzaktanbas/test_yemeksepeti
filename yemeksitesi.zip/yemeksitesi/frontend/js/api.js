async function getMenuData() {
    const res = await fetch("js/menu.json");
    return res.json();
}
