const API_URL = 'http://localhost:3000/api';

function showBox(id) {
  document.querySelectorAll(".login-box").forEach(box => box.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
  // clear messages
  ['customer-msg','restaurant-msg','register-msg','forgot-msg'].forEach(idm => {
    const el = document.getElementById(idm);
    if (el) el.textContent = '';
  });
}

// Geçişler
document.getElementById("to-restaurant").addEventListener("click", (e)=>{ e.preventDefault(); showBox("restaurant-login"); });
document.getElementById("to-customer").addEventListener("click", (e)=>{ e.preventDefault(); showBox("customer-login"); });
document.getElementById("to-register").addEventListener("click", (e)=>{ e.preventDefault(); showBox("register-box"); });
document.getElementById("to-register-rest").addEventListener("click", (e)=>{ e.preventDefault(); showBox("register-box"); });
document.getElementById("to-forgot").addEventListener("click", (e)=>{ e.preventDefault(); showBox("forgot-box"); });
document.getElementById("to-forgot-rest").addEventListener("click", (e)=>{ e.preventDefault(); showBox("forgot-box"); });
document.getElementById("back-to-login").addEventListener("click", (e)=>{ e.preventDefault(); showBox("customer-login"); });
document.getElementById("back-to-login2").addEventListener("click", (e)=>{ e.preventDefault(); showBox("customer-login"); });

// Login - müşteri
document.getElementById("customer-login-btn").addEventListener("click", async () => {
  const email = document.getElementById("customer-email").value.trim();
  const password = document.getElementById("customer-password").value;
  const msgEl = document.getElementById("customer-msg");
  try {
    const res = await fetch(`${API_URL}/login`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ email, password, type: 'customer' })
    });
    const data = await res.json();
    if (res.ok) {
      msgEl.style.color = 'green';
      msgEl.textContent = `Hoşgeldiniz ${data.user.name}`;
      // demo: yönlendirme yerine mesaj. Gerçek uygulamada localStorage/token kaydedip yönlendir.
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'Hata';
    }
  } catch (err) {
    msgEl.style.color = '#c00';
    msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});

// Login - restoran
document.getElementById("restaurant-login-btn").addEventListener("click", async () => {
  const email = document.getElementById("restaurant-email").value.trim();
  const password = document.getElementById("restaurant-password").value;
  const msgEl = document.getElementById("restaurant-msg");
  try {
    const res = await fetch(`${API_URL}/login`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ email, password, type: 'restaurant' })
    });
    const data = await res.json();
    if (res.ok) {
      msgEl.style.color = 'green';
      msgEl.textContent = `Hoşgeldiniz ${data.user.name}`;
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'Hata';
    }
  } catch (err) {
    msgEl.style.color = '#c00';
    msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});

// Register
document.getElementById("register-btn").addEventListener("click", async () => {
  const type = document.getElementById("register-type").value;
  const name = document.getElementById("register-name").value.trim();
  const email = document.getElementById("register-email").value.trim();
  const password = document.getElementById("register-password").value;
  const msgEl = document.getElementById("register-msg");

  if (!name || !email || !password) {
    msgEl.style.color = '#c00'; msgEl.textContent = 'Lütfen tüm alanları doldurun.'; return;
  }

  try {
    const res = await fetch(`${API_URL}/register`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ type, name, email, password })
    });
    const data = await res.json();
    if (res.ok) {
      msgEl.style.color = 'green';
      msgEl.textContent = 'Kayıt başarılı. Giriş sayfasına yönlendiriliyorsunuz...';
      setTimeout(()=> showBox(type === 'restaurant' ? 'restaurant-login' : 'customer-login'), 1200);
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'Kayıt hatası';
    }
  } catch (err) {
    msgEl.style.color = '#c00'; msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});

// Forgot - e-posta kontrolü
document.getElementById("forgot-btn").addEventListener("click", async () => {
  const type = document.getElementById("forgot-type").value;
  const email = document.getElementById("forgot-email").value.trim();
  const msgEl = document.getElementById("forgot-msg");
  if (!email) { msgEl.style.color='#c00'; msgEl.textContent='E-posta girin.'; return; }

  try {
    const res = await fetch(`${API_URL}/forgot`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ type, email })
    });
    const data = await res.json();
    if (res.ok) {
      msgEl.style.color = 'green';
      msgEl.textContent = data.message || 'E-posta bulundu.';
      document.getElementById('new-pass-area').classList.remove('hidden');
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'Bulunamadı';
      document.getElementById('new-pass-area').classList.add('hidden');
    }
  } catch (err) {
    msgEl.style.color = '#c00';
    msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});

// Set New Password
document.getElementById("set-new-pass-btn").addEventListener("click", async () => {
  const type = document.getElementById("forgot-type").value;
  const email = document.getElementById("forgot-email").value.trim();
  const newPass = document.getElementById("new-password").value;
  const newPass2 = document.getElementById("new-password-confirm").value;
  const msgEl = document.getElementById("forgot-msg");

  if (!newPass || !newPass2) { msgEl.style.color='#c00'; msgEl.textContent='Yeni şifre alanlarını doldurun.'; return; }
  if (newPass !== newPass2) { msgEl.style.color='#c00'; msgEl.textContent='Şifreler eşleşmiyor.'; return; }

  try {
    const res = await fetch(`${API_URL}/reset-password`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ type, email, newPassword: newPass })
    });
    const data = await res.json();
    if (res.ok) {
      msgEl.style.color='green';
      msgEl.textContent = data.message || 'Şifre güncellendi.';
      // reset fields & dön
      document.getElementById('new-password').value = '';
      document.getElementById('new-password-confirm').value = '';
      setTimeout(()=> showBox(type === 'restaurant' ? 'restaurant-login' : 'customer-login'), 1200);
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'Hata';
    }
  } catch (err) {
    msgEl.style.color = '#c00';
    msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});


// MÜŞTERİ GİRİŞİ
document.getElementById("customer-login-btn").addEventListener("click", async () => {
  const email = document.getElementById("customer-email").value.trim();
  const password = document.getElementById("customer-password").value;
  const msgEl = document.getElementById("customer-msg");

  try {
    const res = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, type: 'customer' })
    });
    const data = await res.json();

    if (res.ok) {
      msgEl.style.color = 'green';
      msgEl.textContent = `Hoşgeldiniz ${data.user.name}`;
      localStorage.setItem('email', data.user.email);
      localStorage.setItem('userType', 'customer');
      setTimeout(() => window.location.href = "customer.html", 800);
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'E-posta veya şifre hatalı.';
    }
  } catch (err) {
    msgEl.style.color = '#c00';
    msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});

// RESTORAN GİRİŞİ
document.getElementById("restaurant-login-btn").addEventListener("click", async () => {
  const email = document.getElementById("restaurant-email").value.trim();
  const password = document.getElementById("restaurant-password").value;
  const msgEl = document.getElementById("restaurant-msg");

  try {
    const res = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, type: 'restaurant' })
    });
    const data = await res.json();

    if (res.ok) {
      msgEl.style.color = 'green';
      msgEl.textContent = `Hoşgeldiniz ${data.user.name}`;
      localStorage.setItem('email', data.user.email);
      localStorage.setItem('userType', 'restaurant');
      setTimeout(() => window.location.href = "restaurant.html", 800);
    } else {
      msgEl.style.color = '#c00';
      msgEl.textContent = data.message || 'E-posta veya şifre hatalı.';
    }
  } catch (err) {
    msgEl.style.color = '#c00';
    msgEl.textContent = 'Sunucuya bağlanılamadı.';
  }
});


document.addEventListener('DOMContentLoaded', () => {
    
    const dashboardView = document.getElementById('dashboard');
    const profileEditView = document.getElementById('profile-edit-view');
    const menuManagementView = document.getElementById('menu-management-view');
    const menuListContainer = document.getElementById('menu-list-container');
    const mealFormModal = document.getElementById('meal-form-modal');
    const mealForm = document.getElementById('meal-form');
    const modalCloseBtn = mealFormModal.querySelector('.close-button');
    const addMealBtn = document.getElementById('add-new-meal-btn');
    
    // YARDIMCI GÖRÜNÜM DEĞİŞTİRME FONKSİYONU
    function showView(viewId) {
        // Tüm ana görünümleri gizle
        [dashboardView, profileEditView, menuManagementView].forEach(view => {
            if (view) view.style.display = 'none';
        });

        // İstenen görünümü göster
        const viewToShow = document.getElementById(viewId);
        if (viewToShow) {
            // Dashboard grid kullanıyorsa block yerine grid kullan
            viewToShow.style.display = viewId === 'dashboard' ? 'grid' : 'block';
        }

        // Floating butonu sadece menüde göster
        addMealBtn.style.display = viewId === 'menu-management-view' ? 'block' : 'none';
    }

    // --- GEÇİŞLER (Zaten vardı, menü kartı eklendi) ---

    // 1. Profil Yönetimi Kartı
    document.getElementById('card-profile').addEventListener('click', () => {
        showView('profile-edit-view');
    });

    // 2. Menü Yönetimi Kartı
    document.getElementById('card-menu').addEventListener('click', () => {
        showView('menu-management-view');
        // Menüye geçildiğinde kartları yükle
        loadMenuCards();
    });
    
    // 3. Geri Düğmeleri
    document.getElementById('back-to-dashboard').addEventListener('click', () => {
        showView('dashboard');
    });
    // Menü görünümüne özel bir geri butonu eklemek isterseniz buraya da ekleyin
    // Şimdilik sadece ana menü kartından geçiş var kabul ediyoruz.

    // 4. Modal Kapatma
    modalCloseBtn.addEventListener('click', () => {
        mealFormModal.style.display = 'none';
    });
    window.addEventListener('click', (event) => {
        if (event.target == mealFormModal) {
            mealFormModal.style.display = 'none';
        }
    });

    // --- MENÜ YÖNETİMİ İŞLEVLERİ ---

    // Yemek Kartı Oluşturma Fonksiyonu
    function createMealCard(meal) {
        const card = document.createElement('div');
        card.className = 'meal-card';
        card.setAttribute('data-id', meal._id); // API'den gelen ID
        
        card.innerHTML = `
            <img src="${meal.imageUrl || 'placeholder.jpg'}" alt="${meal.name}">
            <div class="card-actions">
                <button class="actions-button" onclick="toggleActionsMenu(this)">...</button>
                <ul class="actions-menu">
                    <li><button data-action="edit">Düzenle</button></li>
                    <li><button data-action="delete">Sil</button></li>
                </ul>
            </div>
            <h4>${meal.name}</h4>
            <p>${meal.description}</p>
            <span class="price">${meal.price.toFixed(2)} $</span>
        `;

        // Düzenle/Sil butonlarına event listener ekle
        card.querySelectorAll('.actions-menu button').forEach(button => {
            button.addEventListener('click', (e) => {
                const action = e.target.getAttribute('data-action');
                if (action === 'edit') {
                    openEditMealModal(meal);
                } else if (action === 'delete') {
                    deleteMeal(meal._id, meal.name);
                }
            });
        });

        return card;
    }
    
    // Üç nokta menüsünü açma/kapama global fonksiyonu (HTML'de onclick kullandık)
    window.toggleActionsMenu = (button) => {
        const menu = button.nextElementSibling;
        // Tüm menüleri kapat
        document.querySelectorAll('.actions-menu').forEach(m => m.classList.remove('show'));
        // Tıklanan menüyü aç/kapat
        menu.classList.toggle('show');
    };
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.card-actions')) {
             document.querySelectorAll('.actions-menu').forEach(m => m.classList.remove('show'));
        }
    });

    // Menüyü Yükleme Fonksiyonu
    async function loadMenuCards() {
        // Burası gerçek API çağrısı yapacak.
        // Şimdilik bir demo veri kullanalım.
        menuListContainer.innerHTML = 'Menü yükleniyor...';
        
        try {
             // API'den menü verisini çek
             // const res = await fetch(`${API_URL}/menu/restaurant-id`);
             // const data = await res.json();
             
             // Demo Veri:
             const demoMenu = [
                 { _id: '1', name: 'Izgara Tavuk', description: 'Özel soslu ızgara tavuk, yanında salata.', price: 12.50, imageUrl: 'https://picsum.photos/id/1080/300/150' },
                 { _id: '2', name: 'Etli Güveç', description: 'Geleneksel usül etli güveç.', price: 18.00, imageUrl: 'https://picsum.photos/id/217/300/150' },
                 // ... diğer yemekler
             ];

             menuListContainer.innerHTML = '';
             demoMenu.forEach(meal => {
                 menuListContainer.appendChild(createMealCard(meal));
             });

             // "Sağda biraz silik bir şekilde artı şekli olsun" isteğiniz için,
             // sadece sol üstteki kartın görünmesi yerine, tüm kartlar listelenir.
             // Yeni kart ekleme işlemi "floating action button" ile yapılır.

        } catch (error) {
             console.error('Menü yüklenirken hata oluştu:', error);
             menuListContainer.innerHTML = '<p style="color:#c00;">Menü yüklenirken hata oluştu. Sunucu bağlantınızı kontrol edin.</p>';
        }
    }

    // Yeni Yemek Ekle Butonu
    addMealBtn.addEventListener('click', () => {
        document.getElementById('meal-form-title').textContent = 'Yeni Yemek Ekle';
        document.getElementById('meal-id-to-edit').value = '';
        mealForm.reset();
        document.getElementById('meal-form-msg').textContent = '';
        mealFormModal.style.display = 'block';
    });

    // Yemek Düzenleme Modalını Açma
    function openEditMealModal(meal) {
        document.getElementById('meal-form-title').textContent = 'Yemek Düzenle';
        document.getElementById('meal-id-to-edit').value = meal._id; // ID'yi forma kaydet
        document.getElementById('meal-name').value = meal.name;
        document.getElementById('meal-description').value = meal.description;
        document.getElementById('meal-price').value = meal.price;
        document.getElementById('meal-image-url').value = meal.imageUrl || '';
        document.getElementById('meal-form-msg').textContent = '';
        mealFormModal.style.display = 'block';
    }

    // Yemek Ekleme/Düzenleme Formu Gönderimi
    mealForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const mealId = document.getElementById('meal-id-to-edit').value;
        const url = mealId ? `${API_URL}/menu/${mealId}` : `${API_URL}/menu`;
        const method = mealId ? 'PUT' : 'POST';
        const msgEl = document.getElementById('meal-form-msg');

        const mealData = {
            name: document.getElementById('meal-name').value,
            description: document.getElementById('meal-description').value,
            price: parseFloat(document.getElementById('meal-price').value),
            imageUrl: document.getElementById('meal-image-url').value,
            // restaurantId: localStorage.getItem('restaurantId') // Gerçek uygulamada restoran ID'si eklenmeli
        };

        try {
            msgEl.textContent = 'Kaydediliyor...';
            // Gerçek API çağrısı
            // const res = await fetch(url, {
            //     method: method,
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(mealData)
            // });
            // const data = await res.json();
            
            // Demo Sonuç:
            const isSuccess = true; 
            
            if (isSuccess) { // (res.ok) yerine
                msgEl.style.color = 'green';
                msgEl.textContent = mealId ? 'Yemek başarıyla güncellendi!' : 'Yeni yemek eklendi!';
                // loadMenuCards(); // Menüyü yeniden yükle
                setTimeout(() => mealFormModal.style.display = 'none', 1000);
            } else {
                msgEl.style.color = '#c00';
                // msgEl.textContent = data.message || 'Hata oluştu.';
                msgEl.textContent = 'Demo hata: Kayıt başarısız.';
            }

        } catch (error) {
            msgEl.style.color = '#c00';
            msgEl.textContent = 'Sunucuya bağlanılamadı.';
        }
    });

    // Yemek Silme Fonksiyonu
    async function deleteMeal(mealId, mealName) {
        if (!confirm(`"${mealName}" adlı yemeği silmek istediğinizden emin misiniz?`)) {
            return;
        }

        try {
            // Gerçek API çağrısı
            // const res = await fetch(`${API_URL}/menu/${mealId}`, {
            //     method: 'DELETE'
            // });

            // Demo Sonuç:
            const isSuccess = true; 
            
            if (isSuccess) { // (res.ok) yerine
                alert(`${mealName} başarıyla silindi.`);
                // loadMenuCards(); // Menüyü yeniden yükle
            } else {
                 alert('Silme işlemi başarısız oldu.');
            }
        } catch (error) {
            alert('Sunucuya bağlanılamadı.');
        }
    }

    // Uygulama yüklendiğinde varsayılan görünümü göster
    showView('dashboard');
});
