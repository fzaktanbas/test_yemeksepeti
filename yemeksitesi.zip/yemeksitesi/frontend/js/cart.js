document.addEventListener("DOMContentLoaded", loadCart);

// SEPETİ YÜKLE
function loadCart() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const cartList = document.getElementById("cart-list");
  const emptyMsg = document.getElementById("empty-cart-message");
  const subTotalEl = document.getElementById("sub-total");
  const grandTotalEl = document.getElementById("grand-total");
  const cartCount = document.getElementById("cart-count");

  cartList.innerHTML = "";
  let total = 0;

  if (cart.length === 0) {
    emptyMsg.style.display = "block";
    subTotalEl.textContent = "0.00 TL";
    grandTotalEl.textContent = "0.00 TL";
    cartCount.textContent = "0";
    return;
  }

  emptyMsg.style.display = "none";
  cartCount.textContent = cart.length;

  cart.forEach((item, i) => {
    const row = document.createElement("div");
    row.className = "cart-item";
    row.innerHTML = `
      <div class="d-flex align-items-center">
        <img src="${item.imageUrl}" width="70" height="70" class="me-3 rounded">
        <div class="flex-grow-1">
          <h5>${item.name}</h5>
          <p class="text-muted small mb-1">${item.restaurant}</p>
          <p>${item.price} ₺ x ${item.quantity}</p>
        </div>
        <button class="btn btn-sm btn-danger" onclick="removeItem(${i})">Sil</button>
      </div>
    `;
    cartList.appendChild(row);
    total += item.price * item.quantity;
  });

  subTotalEl.textContent = `${total.toFixed(2)} TL`;
  grandTotalEl.textContent = `${total.toFixed(2)} TL`;
}

// SEPETTEN ÜRÜN SİL
function removeItem(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  loadCart();
}

// SİPARİŞİ ONAYLA (şimdilik sadece sepeti temizler)
document.getElementById("place-order-btn").addEventListener("click", () => {
  alert("Siparişiniz alındı! Teşekkür ederiz 💖");
  localStorage.removeItem("cart");
  loadCart();
});

// ÇIKIŞ
document.getElementById("logout").addEventListener("click", () => {
  localStorage.removeItem("userType");
  localStorage.removeItem("email");
  window.location.href = "index.html";
});
