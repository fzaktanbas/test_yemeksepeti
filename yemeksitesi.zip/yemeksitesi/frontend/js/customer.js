const API_URL = 'http://localhost:3000/api';

// Oturum kontrolü
const email = localStorage.getItem('email');
const type = localStorage.getItem('userType');
if (!email || type !== 'customer') {
  window.location.href = "index.html";
}

// DOM öğeleri
const restaurantListView = document.getElementById('restaurant-list-view');
const restaurantDetailView = document.getElementById('restaurant-detail-view');
const restaurantListContainer = document.getElementById('restaurant-list-container');
const restaurantInfo = document.getElementById('restaurant-info');
const restaurantMenuContainer = document.getElementById('restaurant-menu-container');
const backToListBtn = document.getElementById('back-to-list');

// RESTORANLARI YÜKLE
async function loadRestaurants() {
  try {
    const res = await fetch(`${API_URL}/restaurant/all`);
    const data = await res.json();

    restaurantListContainer.innerHTML = '';

    data.forEach(r => {
      const card = document.createElement('div');
      card.className = 'restaurant-card';
      card.innerHTML = `
        <img src="${r.restaurantImage || 'https://via.placeholder.com/300x150'}">
        <h3>${r.restaurantName}</h3>
        <p>${r.restaurantAddress}</p>
      `;
      card.addEventListener('click', () => showRestaurantDetail(r));
      restaurantListContainer.appendChild(card);
    });
  } catch (err) {
    console.error(err);
    restaurantListContainer.innerHTML = '<p>Restoranlar yüklenemedi.</p>';
  }
}

// RESTORAN DETAY GÖRÜNÜMÜ
async function showRestaurantDetail(restaurant) {
  restaurantListView.style.display = 'none';
  restaurantDetailView.style.display = 'block';

  restaurantInfo.innerHTML = `
  <div id="restaurant-info">
    <img src="${restaurant.restaurantImage || 'https://via.placeholder.com/800x300'}" alt="${restaurant.restaurantName}">
    <div class="restaurant-details">
      <h2>${restaurant.restaurantName}</h2>
      <p class="description">${restaurant.restaurantDescription || ''}</p>
      <p class="address"><strong>Adres:</strong> ${restaurant.restaurantAddress}</p>
    </div>
  </div>
`;

  try {
    const res = await fetch(`${API_URL}/menu/restaurant?email=${encodeURIComponent(restaurant.email)}`);
    const menu = await res.json();

    restaurantMenuContainer.innerHTML = '';

    // 🔹 MENÜ KARTLARI
    if (Array.isArray(menu) && menu.length > 0) {
      menu.forEach(meal => {
        const mealCard = document.createElement('div');
        mealCard.className = 'meal-card';
        mealCard.innerHTML = `
          <img src="${meal.imageUrl || 'https://via.placeholder.com/150'}" alt="${meal.name}">
          <h4>${meal.name}</h4>
          <p>${meal.description}</p>
          <strong>${meal.price} ₺</strong>
          <button class="add-to-cart-btn">🛒 Sepete Ekle</button>
        `;

        // 🛒 Sepete ekleme işlemi
        mealCard.querySelector('.add-to-cart-btn').addEventListener('click', () => {
          addToCart({
            name: meal.name,
            price: meal.price,
            imageUrl: meal.imageUrl,
            description: meal.description,
            restaurant: restaurant.restaurantName
          });
        });

        restaurantMenuContainer.appendChild(mealCard);
      });
    } else {
      restaurantMenuContainer.innerHTML = '<p>Bu restoranda menü bulunmuyor.</p>';
    }
  } catch (err) {
    console.error(err);
    restaurantMenuContainer.innerHTML = '<p>Menü yüklenemedi.</p>';
  }
}

// 🛒 SEPETE EKLEME FONKSİYONU
function addToCart(item) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  const existing = cart.find(x => x.name === item.name && x.restaurant === item.restaurant);
  if (existing) {
    existing.quantity += 1;
  } else {
    item.quantity = 1;
    cart.push(item);
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`${item.name} sepete eklendi!`);
}

// 🔙 Geri dön butonu
backToListBtn.addEventListener('click', () => {
  restaurantListView.style.display = 'block';
  restaurantDetailView.style.display = 'none';
});

// Sayfa yüklenince restoranları getir
document.addEventListener('DOMContentLoaded', loadRestaurants);

// Çıkış
document.getElementById("logout").addEventListener("click", () => {
  localStorage.removeItem("userType");
  localStorage.removeItem("email");
  window.location.href = "index.html";
});
