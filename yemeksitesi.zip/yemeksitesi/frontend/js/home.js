// =================================================================
// 1. AYARLAR VE OTURUM KONTROLÜ
// =================================================================
const API_URL = 'http://localhost:3000/api';
const currentUserId = localStorage.getItem('email'); // Restoranın e-postası

// Çıkış Yapma İşlemi
document.getElementById("logout").addEventListener("click", () => {
  localStorage.removeItem("userType");
  localStorage.removeItem("email");
  window.location.href = "index.html";
});

// Oturum Kontrolü
if (!currentUserId || localStorage.getItem("userType") !== 'restaurant') {
  window.location.href = "index.html";
}

// =================================================================
// 2. SAYFA YÜKLENDİĞİNDE
// =================================================================
document.addEventListener('DOMContentLoaded', () => {

  const dashboard = document.getElementById('dashboard');
  const profileEditView = document.getElementById('profile-edit-view');
  const menuManagementView = document.getElementById('menu-management-view');
  const menuListContainer = document.getElementById('menu-list-container');
  const addMealBtn = document.getElementById('add-new-meal-btn');
  const mealFormModal = document.getElementById('meal-form-modal');
  const mealForm = document.getElementById('meal-form');
  const modalCloseBtn = mealFormModal?.querySelector('.close-button');

  const previewContainer = document.getElementById('preview-container'); // <<<<< EKLE

  const menuCard = document.getElementById('card-menu');
  const ordersCard = document.getElementById('card-orders');
  const profileCard = document.getElementById('card-profile');
  const backButton = document.getElementById('back-to-dashboard');

  // Görünüm değiştirme
  const showView = (viewId) => {
    dashboard.style.display = 'none';
    profileEditView.style.display = 'none';
    menuManagementView.style.display = 'none';

    addMealBtn.style.display = (viewId === 'menu-edit') ? 'block' : 'none';

    if (viewId === 'dashboard') {
      dashboard.style.display = 'grid';
    } else if (viewId === 'profile-edit') {
      profileEditView.style.display = 'block';
      loadRestaurantData();
    } else if (viewId === 'menu-edit') {
      menuManagementView.style.display = 'block';
      loadMenuCards();
    }
  };

  showView('dashboard');

  profileCard.addEventListener('click', () => showView('profile-edit'));
  menuCard.addEventListener('click', () => showView('menu-edit'));
  ordersCard.addEventListener('click', () => alert("Siparişler ekranı yakında geliyor..."));
  backButton?.addEventListener('click', () => showView('dashboard'));

  // Modal kapatma
  modalCloseBtn?.addEventListener('click', () => (mealFormModal.style.display = 'none'));
  window.addEventListener('click', (e) => {
    if (e.target == mealFormModal) mealFormModal.style.display = 'none';
  });

  // =================================================================
  // 3. PROFİL YÖNETİMİ
  // =================================================================
  async function loadRestaurantData() {
    try {
      const res = await fetch(`${API_URL}/restaurant/get?email=${encodeURIComponent(currentUserId)}`);
      const result = await res.json();
      if (result.success && result.data) {
        const r = result.data;
        document.getElementById('restaurant-name').value = r.restaurantName || '';
        document.getElementById('restaurant-address').value = r.restaurantAddress || '';
        document.getElementById('restaurant-image').value = r.restaurantImage || '';
        document.getElementById('restaurant-description').value = r.restaurantDescription || '';

        const preview = document.getElementById('current-image-preview');
        preview.innerHTML = r.restaurantImage
          ? `<img src="${r.restaurantImage}" style="width:150px;border-radius:8px;">`
          : '';
      }
    } catch (err) {
      console.error("Restoran verisi yüklenemedi:", err);
    }
  }

  // Profil Güncelleme
  document.getElementById('restaurant-profile-form').addEventListener('click', async (e) => {
    if (!e.target.classList.contains('save-button')) return;

    const button = e.target;
    const fieldName = button.getAttribute('data-field');
    const input = document.querySelector(`[name="${fieldName}"]`);
    const value = input.value;

    button.textContent = "Kaydediliyor...";
    button.disabled = true;

    try {
      const res = await fetch(`${API_URL}/restaurant/update-profile`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUserId, [fieldName]: value })
      });

      const result = await res.json();
      if (result.success) {
        button.textContent = "✅ Kaydedildi!";
        button.style.backgroundColor = "#28a745";
        if (fieldName === "restaurantImage") loadRestaurantData();
      } else {
        button.textContent = "❌ Hata!";
        button.style.backgroundColor = "#c00";
      }
    } catch (err) {
      console.error(err);
      button.textContent = "❌ Sunucu Hatası!";
      button.style.backgroundColor = "#c00";
    } finally {
      setTimeout(() => {
        button.textContent = "Kaydet";
        button.style.backgroundColor = "";
        button.disabled = false;
      }, 1500);
    }
  });

  // =================================================================
  // 4. MENÜ YÖNETİMİ
  // =================================================================

  // Kart oluşturma
  function createMealCard(meal) {
    const card = document.createElement('div');
    card.className = 'meal-card';
    card.innerHTML = `
      <img src="${meal.imageUrl || 'https://via.placeholder.com/300x150?text=Görsel+Yok'}" alt="${meal.name}">
      <div class="card-actions">
        <button class="actions-button" onclick="toggleActionsMenu(this)">...</button>
        <ul class="actions-menu">
          <li><button data-action="edit">Düzenle</button></li>
          <li><button data-action="delete">Sil</button></li>
        </ul>
      </div>
      <h4>${meal.name}</h4>
      <p>${meal.description}</p>
      <span class="price">${meal.price?.toFixed(2) || '0.00'} $</span>
    `;

    card.querySelectorAll('.actions-menu button').forEach(btn => {
      const action = btn.getAttribute('data-action');
      btn.addEventListener('click', () => {
        if (action === 'edit') openEditMealModal(meal);
        if (action === 'delete') deleteMeal(meal._id, meal.name);
      });
    });

    return card;
  }

  window.toggleActionsMenu = (btn) => {
    const menu = btn.nextElementSibling;
    document.querySelectorAll('.actions-menu').forEach(m => m.classList.remove('show'));
    menu.classList.toggle('show');
  };

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.card-actions'))
      document.querySelectorAll('.actions-menu').forEach(m => m.classList.remove('show'));
  });

  // Menü yükleme
  async function loadMenuCards() {
    if (!menuListContainer) return;
    menuListContainer.innerHTML = 'Menü yükleniyor...';
    try {
      const res = await fetch(`${API_URL}/menu/restaurant?email=${encodeURIComponent(currentUserId)}`);
      const menuData = await res.json();
      menuListContainer.innerHTML = '';

      if (Array.isArray(menuData)) {
        menuData.forEach(meal => menuListContainer.appendChild(createMealCard(meal)));
      } else {
        menuListContainer.innerHTML = `<p style="color:#c00;">${menuData.message || 'Menü alınamadı.'}</p>`;
      }
    } catch (err) {
      console.error(err);
      menuListContainer.innerHTML = '<p style="color:#c00;">Sunucuya bağlanılamadı.</p>';
    }
  }

  // Yeni Yemek Ekle Butonu
    if (addMealBtn) {
        addMealBtn.addEventListener('click', () => {
            document.getElementById('meal-form-title').textContent = 'Yeni Yemek Ekle';
            document.getElementById('meal-id-to-edit').value = '';
            mealForm.reset();
            document.getElementById('meal-form-msg').textContent = '';
            previewContainer.innerHTML = ''; // Görsel önizlemeyi temizle
            // YENİ EKLENEN GİZLİ ALAN
            document.getElementById('meal-current-image-url').value = ''; 
            mealFormModal.style.display = 'block';
        });
    }

    // Yemek Düzenleme Modalını Açma
    function openEditMealModal(meal) {
        document.getElementById('meal-form-title').textContent = 'Yemek Düzenle';
        document.getElementById('meal-id-to-edit').value = meal._id;
        document.getElementById('meal-name').value = meal.name;
        document.getElementById('meal-description').value = meal.description;
        document.getElementById('meal-price').value = meal.price;
        
        // YENİ EKLENEN: Mevcut URL'yi gizli alana kaydet (eğer yeni görsel yüklenmezse kullanılacak)
        document.getElementById('meal-current-image-url').value = meal.imageUrl || ''; 
        
        // Görsel önizlemesi
        previewContainer.innerHTML = meal.imageUrl
            ? `<img src="${meal.imageUrl}" alt="Mevcut Görsel" style="max-width: 100px; margin-top: 10px; border-radius: 5px;">`
            : '';
            
        document.getElementById('meal-image-file').value = ''; // Dosya inputunu sıfırla
        document.getElementById('meal-form-msg').textContent = '';
        mealFormModal.style.display = 'block';
    }

    // Yemek Ekleme/Düzenleme Formu Gönderimi (GÖRSEL YÜKLEMEYİ İÇEREN GÜNCEL BLOK)
    if (mealForm) {
        mealForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const mealId = document.getElementById('meal-id-to-edit').value;
            let url = `${API_URL}/menu/add`;
            let method = 'POST';

            if (mealId) {
                url = `${API_URL}/menu/update/${mealId}`;
                method = 'PUT';
            }

            const msgEl = document.getElementById('meal-form-msg');
            msgEl.textContent = 'İşleniyor...';
            msgEl.style.color = 'orange';

            // 1. GÖRSEL YÜKLEME İŞLEMİ (Eğer dosya seçilmişse)
            const imageFile = document.getElementById('meal-image-file').files[0];
            // YENİ EKLENEN: Mevcut görselin URL'sini gizli alandan al
            let imageUrl = document.getElementById('meal-current-image-url').value || ''; 

            if (imageFile) {
                msgEl.textContent = 'Görsel yükleniyor...';
                const uploadFormData = new FormData();
                uploadFormData.append('image', imageFile);

                try {
                    const uploadRes = await fetch(`${API_URL}/menu/upload`, {
                        method: 'POST',
                        body: uploadFormData, // FormData gönder
                    });

                    const uploadData = await uploadRes.json();
                    if (uploadData.success) {
                        imageUrl = uploadData.imageUrl;
                        msgEl.textContent = 'Görsel başarıyla yüklendi.';
                    } else {
                        throw new Error(uploadData.message || 'Görsel yükleme hatası.');
                    }
                } catch (error) {
                    msgEl.style.color = '#c00';
                    msgEl.textContent = `Görsel yüklenirken hata oluştu: ${error.message}`;
                    return; // Hata durumunda işlemi durdur
                }
            }
            
            // 2. YEMEK VERİLERİNİ GÖNDERME
            const mealData = {
                name: document.getElementById('meal-name').value,
                description: document.getElementById('meal-description').value,
                price: parseFloat(document.getElementById('meal-price').value),
                // Yüklenen URL'yi, mevcut URL'yi (eğer dosya seçilmediyse) veya boş stringi kullan
                imageUrl: imageUrl, 
                restaurantEmail: currentUserId
            };

            if (mealId) {
                mealData._id = parseInt(mealId);
            }


            try {
                msgEl.textContent = 'Yemek bilgileri kaydediliyor...';

                const res = await fetch(url, {
                    method: method,
                    headers: { 'Content-Type': 'application/json' }, // JSON verisi gönderiyoruz
                    body: JSON.stringify(mealData)
                });

                const data = await res.json();

                if (res.ok) {
                    msgEl.style.color = 'green';
                    msgEl.textContent = data.message || (mealId ? 'Yemek başarıyla güncellendi!' : 'Yeni yemek eklendi!');
                    loadMenuCards(); // Menüyü yeniden yükle
                    setTimeout(() => mealFormModal.style.display = 'none', 1000);
                } else {
                    msgEl.style.color = '#c00';
                    msgEl.textContent = data.message || 'Kayıt sırasında hata oluştu.';
                }

            } catch (error) {
                msgEl.style.color = '#c00';
                msgEl.textContent = 'Sunucuya bağlanılamadı. API çağrısında hata.';
            }
        });
    }

    // Yemek Silme Fonksiyonu
    async function deleteMeal(mealId, mealName) {
        if (!confirm(`"${mealName}" adlı yemeği silmek istediğinizden emin misiniz?`)) {
            return;
        }

        try {
            // Silme URL'sine silinecek yemeğin ID'si ve restoran e-postasını ekledik.
            const res = await fetch(`${API_URL}/menu/${mealId}?email=${encodeURIComponent(currentUserId)}`, {
                method: 'DELETE'
            });

            const data = await res.json();

            if (res.ok) {
                alert(`${mealName} başarıyla silindi.`);
                loadMenuCards(); // Menüyü yeniden yükle
            } else {
                alert(data.message || 'Silme işlemi başarısız oldu.');
            }
        } catch (error) {
            alert('Sunucuya bağlanılamadı.');
        }
    }
});


