// server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const multer = require('multer');

const app = express();
app.use(cors());
app.use(express.json());

// ==================== DOSYA YÜKLEME (UPLOAD) AYARLARI ====================
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // uploads klasörü
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + file.originalname;
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });
app.use('/uploads', express.static('uploads')); // klasörü herkese açık yap

// ==================== DOSYA YOLLARI ====================
const PORT = process.env.PORT || 3000;
const USERS_DATA_PATH = path.join(__dirname, 'data', 'users.json');
const RESTAURANT_DATA_PATH = path.join(__dirname, 'data', 'restaurants.json');
const MENU_DATA_PATH = path.join(__dirname, 'data', 'menu.json');

// ==================== ORTAK DOSYA İŞLEVLERİ ====================
function readUserData() {
  try {
    const raw = fs.readFileSync(USERS_DATA_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    console.error("Hata: users.json okunamadı veya bozuk.", e);
    return { customers: [], restaurants: [], nextId: 1 };
  }
}

function writeUserData(data) {
  try {
    fs.writeFileSync(USERS_DATA_PATH, JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    console.error("Hata: users.json yazılamadı.", e);
  }
}

function readRestaurantData() {
  try {
    const raw = fs.readFileSync(RESTAURANT_DATA_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    console.error("Hata: restaurants.json okunamadı veya bozuk.", e);
    return [];
  }
}

function writeRestaurantData(data) {
  try {
    fs.writeFileSync(RESTAURANT_DATA_PATH, JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    console.error("Hata: restaurants.json yazılamadı.", e);
  }
}

function readMenuData() {
  try {
    const raw = fs.readFileSync(MENU_DATA_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    console.error("menu.json okunamadı:", e);
    return { menuData: {}, nextMealId: 1 };
  }
}

function writeMenuData(data) {
  fs.writeFileSync(MENU_DATA_PATH, JSON.stringify(data, null, 2), 'utf8');
}

// ==================== LOGIN / REGISTER / ŞİFRE ====================

// Login
app.post('/api/login', (req, res) => {
  const { email, password, type } = req.body;
  const data = readUserData();
  const list = type === 'restaurant' ? data.restaurants : data.customers;
  const user = list.find(u => u.email === email && u.password === password);
  if (user) {
    res.json({ ok: true, user: { id: user.id, name: user.name, email: user.email } });
  } else {
    res.status(401).json({ ok: false, message: 'E-posta veya şifre hatalı.' });
  }
});

// Register
app.post('/api/register', (req, res) => {
  const { email, password, name, type } = req.body;
  if (!email || !password || !name || !type)
    return res.status(400).json({ ok: false, message: 'Eksik alan' });

  const data = readUserData();
  const list = type === 'restaurant' ? data.restaurants : data.customers;

  if (list.find(u => u.email === email)) {
    return res.status(409).json({ ok: false, message: 'Bu e-posta zaten kayıtlı.' });
  }

  const newUser = { id: data.nextId || Date.now(), email, password, name };
  list.push(newUser);
  data.nextId = (data.nextId || (Date.now() + 1)) + 1;
  writeUserData(data);
  res.json({ ok: true, user: { id: newUser.id, name: newUser.name, email: newUser.email } });
});

// Forgot Password
app.post('/api/forgot', (req, res) => {
  const { email, type } = req.body;
  const data = readUserData();
  const list = type === 'restaurant' ? data.restaurants : data.customers;
  const user = list.find(u => u.email === email);
  if (user) {
    res.json({ ok: true, message: 'Kullanıcı bulundu. Yeni şifre oluşturabilirsiniz.' });
  } else {
    res.status(404).json({ ok: false, message: 'Bu e-posta ile kayıtlı kullanıcı bulunamadı.' });
  }
});

// Reset Password
app.post('/api/reset-password', (req, res) => {
  const { email, type, newPassword } = req.body;
  if (!email || !newPassword)
    return res.status(400).json({ ok: false, message: 'Eksik alan' });

  const data = readUserData();
  const list = type === 'restaurant' ? data.restaurants : data.customers;
  const user = list.find(u => u.email === email);
  if (!user) return res.status(404).json({ ok: false, message: 'Kullanıcı bulunamadı.' });

  user.password = newPassword;
  writeUserData(data);
  res.json({ ok: true, message: 'Şifre başarıyla güncellendi.' });
});

// ==================== RESTORAN PROFİL API ====================

// Restoran verisini getir
app.get("/api/restaurant/get", (req, res) => {
  const email = req.query.email;
  if (!email) return res.status(400).json({ success: false, message: "E-posta gerekli" });

  const data = readRestaurantData();
  const restaurant = data.find(r => r.email === email);

  if (restaurant) res.json({ success: true, data: restaurant });
  else res.json({ success: false, message: "Restoran bulunamadı" });
});

// TÜM RESTORANLARI GETİR
app.get('/api/restaurant/all', (req, res) => {
  const data = readRestaurantData(); // readRestaurantData() zaten senin sisteminde var
  res.json(data);
});


// Restoran verisini güncelle / kaydet
app.post("/api/restaurant/update-profile", (req, res) => {
  const { userId, ...updatedFields } = req.body;

  if (!userId)
    return res.status(400).json({ success: false, message: "userId (e-posta) gerekli" });

  const data = readRestaurantData();
  let restaurantIndex = data.findIndex(r => r.email === userId);
  let restaurant;

  if (restaurantIndex !== -1) {
    restaurant = { ...data[restaurantIndex], ...updatedFields };
    data[restaurantIndex] = restaurant;
  } else {
    restaurant = {
      email: userId,
      restaurantName: updatedFields.restaurantName || "",
      restaurantAddress: updatedFields.restaurantAddress || "",
      restaurantImage: updatedFields.restaurantImage || "",
      restaurantDescription: updatedFields.restaurantDescription || "",
    };
    data.push(restaurant);
  }

  writeRestaurantData(data);
  res.json({ success: true, message: "Profil kaydedildi", data: restaurant });
});

// ==================== MENÜ API ====================

// Menüleri getir
app.get('/api/menu/restaurant', (req, res) => {
  const email = req.query.email;
  if (!email) return res.status(400).json({ message: 'email parametresi eksik' });

  const data = readMenuData();
  const menu = data.menuData[email] || [];
  res.json(menu);
});

// Yeni yemek ekle
app.post("/api/menu/add", (req, res) => {
  const { restaurantEmail, name, description, price, imageUrl } = req.body;

  if (!restaurantEmail || !name) {
    return res.status(400).json({ success: false, message: "Eksik alanlar var." });
  }

  const db = readMenuData(); // ✅ artık doğru dosyayı okuyor
  const newMeal = {
    _id: db.nextMealId++,
    name,
    description,
    price,
    imageUrl
  };

  if (!db.menuData[restaurantEmail]) {
    db.menuData[restaurantEmail] = [];
  }

  db.menuData[restaurantEmail].push(newMeal);

  writeMenuData(db); // ✅ tutarlı yazma işlemi
  res.json({ success: true, message: "Yemek başarıyla eklendi!" });
});

// Yemek güncelle
app.put('/api/menu/update/:id', (req, res) => {
  const mealId = parseInt(req.params.id);
  const { restaurantEmail, name, description, price, imageUrl } = req.body;

  const data = readMenuData();
  const restaurantMeals = data.menuData[restaurantEmail];
  if (!restaurantMeals) return res.status(404).json({ message: 'Restoran bulunamadı' });

  const index = restaurantMeals.findIndex(m => m._id === mealId);
  if (index === -1) return res.status(404).json({ message: 'Yemek bulunamadı' });

  restaurantMeals[index] = { _id: mealId, name, description, price, imageUrl };
  writeMenuData(data);

  res.json({ success: true, message: 'Yemek güncellendi' });
});

// Yemek sil
app.delete('/api/menu/:id', (req, res) => {
  const mealId = parseInt(req.params.id);
  const email = req.query.email;

  const data = readMenuData();
  const restaurantMeals = data.menuData[email];
  if (!restaurantMeals) return res.status(404).json({ message: 'Restoran bulunamadı' });

  const index = restaurantMeals.findIndex(m => m._id === mealId);
  if (index === -1) return res.status(404).json({ message: 'Yemek bulunamadı' });

  restaurantMeals.splice(index, 1);
  writeMenuData(data);

  res.json({ success: true, message: 'Yemek silindi' });
});

// ==================== GÖRSEL YÜKLEME (UPLOAD ENDPOINT) ====================
app.post('/api/menu/upload', upload.single('image'), (req, res) => {
  if (!req.file)
    return res.status(400).json({ success: false, message: 'Dosya yüklenemedi' });

  const imageUrl = `http://localhost:${PORT}/uploads/${req.file.filename}`;
  res.json({ success: true, imageUrl });
});




// ==================== SUNUCU BAŞLAT ====================
app.listen(PORT, () => {
  console.log(`✅ Sunucu http://localhost:${PORT} adresinde çalışıyor`);
  console.log(`Veri yolu: ${USERS_DATA_PATH}`);
});
